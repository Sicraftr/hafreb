const Discord = require("discord.js"); 
const client = new Discord.Client(); 
const fs = require("fs");
const http = require("http");
let serverData = require('./storage/serverData.json');
var {init} = require('./setupServer');
require('./ExtendedMessage')

client.login('NzM5MTAxMjUyNDgyMzY3NTEx.XyVjrg.642ScfxlS6HlSHq9lwBEybUTaz4')

client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();

fs.readdir(`./comandos/`, (err, files) => {
    if (err) console.log(err)
var jsfile = files.filter(f => f.split(".").pop() === "js") 
jsfile.forEach((f, i) => {
        let pull = require(`./comandos/${f}`)
        client.commands.set(pull.config.name, pull);
        pull.config.aliases.forEach(alias => {
            client.aliases.set(alias, pull.config.name)
          
          console.log('[ COMANDOS ] O comando ' + f + ' foi carregado com sucesso.')
          if(err) console.log('[ COMANDOS ] O comando ' + f + ' não foi carregado com sucesso.')
        });        
    });
});

fs.readdir("./events/", (err, files) => {
  if (err) return console.error(`[Error] > Houve um erro:\n${err}`);
  files.forEach(file => {
    let eventFunction = require(`./events/${file}`);
    console.log(`[Evento] ${file}`);
    let eventName = file.split(".")[0];
    client.on(eventName, (...args) => eventFunction.run(client, ...args));
  });
});  


client.on("guildCreate", guild => {
  fs.writeFile("./storage/serverData.json", JSON.stringify(serverData), (err) => {
    if(err) console.log(err)
  })

  init(guild);
})

client.on("ready", () => {
    console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    console.log(client.user.username + " " + "started successfully!")
    console.log(client.guilds.cache.size + " " + "guilds.")
    console.log(client.users.cache.size + " " + "users.")
    console.log(client.channels.cache.size + " " + "channels.")
    console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    


    let status = [
        {name: `Ajudando a configurar`, type: `STREAMING`, url: `https://www.twitch.tv/Discord`},
        {name: `Meu desemvolvimento`, type: `WATCHING`, url: `https://youtu.be/z6rt1hdDGaE`}
    ]
      //O client vai mudar o status aleatoriamente
      function setStatus() {
         let randomStatus = status[Math.floor(Math.random() * status.length)];
         client.user.setActivity(randomStatus.name, { type: randomStatus.type, url: randomStatus.url });
      }
      setStatus();
      setInterval(setStatus, 15000);
})

client.on('guildMemberAdd', member => {
  member.roles.add('821031867356545054')
  member.roles.add(member.guild.roles.cache.find(role => role.id === "821031867356545054"));

let entrada = client.channels.cache.get('821031899043987496')
  entrada.send(
    
    ` Olá, ${member.user}, seja bem vindo(a) ao servidor. `);
})


client.on("message", async message => {
  if(message.author.bot || message.channel.type === 'dm') return
  
  let messageArray = message.content.split(" "); 
  let prefix = "/";
  let args = messageArray.slice(1);
  let cmd = messageArray[0];
  if(!message.content.startsWith("/")) return;
let archive = client.commands.get(cmd.slice(prefix.length)) || client.commands.get(client.aliases.get(cmd.slice(prefix.length))) 
if(archive)archive.run(client, message, args, prefix)

});

client.on('message', message => {
  if (message.author.bot) return;
  if (message.channel.type === 'dm') return;

  if (message.mentions.users.first() === client.user){
    const exampleEmbed = new Discord.MessageEmbed()
    .setColor('#2f3136')
    .addField('Ajuda rápida', "Olá, acabei de ser mencionado, Use meus comandos no <#848503248594665492>.", true)
    .setFooter(`Comando enviado para: ${message.author.tag}`, `${message.author.avatarURL()}`)
      message.channel.send(exampleEmbed).then(m=>m.delete({timeout: 5000}))
  }
}); 

client.on("guildCreate", guild => {
  fs.writeFile("./storage/serverData.json", JSON.stringify(serverData), (err) => {
    if(err) console.log(err)
  })

  init(guild);
})

const express = require('express');
const app = express();
app.get("/", (request, response) => {
  const ping = new Date();
  ping.setHours(ping.getHours() - 3);
  console.log(`${ping.getUTCHours()}:${ping.getUTCMinutes()}:${ping.getUTCSeconds()}`);
  response.sendStatus(200);
});
app.listen(process.env.PORT)



