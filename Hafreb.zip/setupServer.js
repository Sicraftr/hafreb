const init = guild => {
    const fs = require('fs');
    let serverData = require('./storage/serverData.json');

    if(!serverData[guild.id]){
        serverData[guild.id] = {
          "supportChannel": 0
        }
        fs.writeFile('./storage/serverData.json', JSON.stringify(serverData, null, 2), (err) => {
          if (err) console.log(err)
        })
    }
}

exports.init = init;