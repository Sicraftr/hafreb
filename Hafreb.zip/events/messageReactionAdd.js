const db = require('quick.db');
const { MessageEmbed, MessageAttachment, Discord } = require('discord.js');
const { ICONS, AchievementCreator } = require("mc-achievements");


module.exports.run = async (bot, reaction, user, message, args, guild) => {
    if (user.partial) await user.fetch();
    if (reaction.partial) await reaction.fetch();
    if (reaction.message.partial) await reaction.message.fetch();

    if (user.bot) return;

    var pessoa = user.discriminator
    
    if (reaction.message.guild) {
        let ticketID = await db.get(`${reaction.message.guild.id}-tickets`)
        if (!ticketID) return;
        AchievementCreator.create(ICONS.book, `${user.username}`, "Ticket criado com sucesso.").then(buffer => {
            /*
            Buffer of the achievement you created.
            Do whatever you want with buffer.
            In this example, we save buffer as a local file.
            */
            const att = new MessageAttachment(buffer, `ticket.png`)

        if (reaction.message.id === ticketID) {
			//if (reaction.message.channel.name.includes(`ticket-parcerias`) || reaction.message.channel.name.includes(`ticket-bugs`) || reaction.message.channel.name.includes(`ticket-outros`) || reaction.message.channel.name.includes(`ticket-duvidas`) || reaction.message.channel.name.includes(`ticket-reports`)) {
            if (!reaction.message.guild.channels.cache.find(x => x.name === `•${user.discriminator}┋${user.id}`)) {
                if (['🛒', '👨‍⚖️', '❓', '🔧', 'girando','YouTube'].includes(reaction.emoji.name)) {
                    reaction.message.channel.send(att).then(i => i.delete({ timeout: 1000 }));
                    reaction.users.remove(user);
                    reaction.message.guild.channels.create(`•${user.discriminator}┋${user.id}`, {
                        type: 'text',
                        permissionOverwrites: [
                            {
                                id: user.id,
                                allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
                            },
                            {
                                id: reaction.message.guild.roles.everyone,
                                deny: ['VIEW_CHANNEL']
                            }
                        ]
                    }).then(async channel => {
                        let embed = new MessageEmbed()
                        .setColor("#2f3136")
                        .setTitle(`TICKET CRIADO`)
                        .setDescription(`Ticket criado com êxito. Este canal atenderá a sua necessidade de atendimento direto com os suportes da equipe, portanto, utilize-o apenas para isso.`)
                        .addField(`Obs.:`,`Caso queira chamar uma alguma pessoa para o ticket chame alguém da equipe pra adicionar para você nesse ticket`,true)
                        switch (reaction.emoji.name) {
                            case '🛒':
                                embed.setDescription(embed.description + `\n\nTipo do ticket: \`Sobre compras\`\nEncerrar o ticket: \`/ticket fechar\` ou reaja com 🔓.`)
                                channel.send(`<@${user.id}>`, embed).then(async msg => {
                                    msg.react('🔓')
                                })
                                channel.setName(`•${user.discriminator}┋${user.id}`);
                                var role = reaction.message.guild.roles.cache.find(x => x.id === ['827507956530282536'])
                                reaction.message.guild.channels.cache.forEach((channel) => {
                                    channel.createOverwrite(role, {
                                        SEND_MESSAGES: true,
                                        ADD_REACTIONS: true,
                                        CONNECT: true
                                    }).catch(() => {});
                                })
                                break;
                            case '👨‍⚖️':
                                embed.setDescription(embed.description + `\n\nTipo do ticket: \`Reportar infratores.\`\nEncerrar o ticket: Reaja com 🔓.`)
                                channel.send(`<@${user.id}>`, embed).then(async msg => {
                                    msg.react('🔓')
                                })
                                channel.setName(`•${user.discriminator}┋${user.id}`);
                                break;
                            case '❓':
                                embed.setDescription(embed.description + `\n\nTipo do ticket: \`Dúvidas relacionadas ao servidor.\`\nEncerrar o ticket: Reaja com 🔓.`)
                                channel.send(`<@${user.id}>`, embed).then(async msg => {
                                    msg.react('🔓')
                                })
                                channel.setName(`•${user.discriminator}┋${user.id}`);
                                break;
                            case 'girando':
                                embed.setDescription(embed.description + `\n\nTipo do ticket: \`Reporte de bugs relacionados ao servidor.\`\nEncerrar o ticket: Reaja com 🔓.`)
                                channel.send(`<@${user.id}>`, embed).then(async msg => {
                                    msg.react('🔓')
                                })
                                channel.setName(`•${user.discriminator}┋${user.id}`);
                                break;
                            case '🔧':
                                embed.setDescription(embed.description + `\n\nTipo do ticket: \`Outros assuntos.\`\nEncerrar o ticket: Reaja com 🔓.`)
                                channel.send(`<@${user.id}>`, embed).then(async msg => {
                                    msg.react('🔓');
                                })
                                channel.setName(`•${user.discriminator}┋${user.id}`);
                                break;
                            case 'YouTube':
                                embed.setDescription(embed.description + `\n\nTipo do ticket: \`Solicitar Tag.\`\nEncerrar o ticket: Reaja com 🔓.`)
                                channel.send(`<@${user.id}>`, embed).then(async msg => {
                                    msg.react('🔓');
                                })
                                channel.setName(`•${user.discriminator}┋${user.id}`);
                                break;
                        }
                    })
                }
            } else {
                reaction.users.remove(user);
                user.send(`Desculpe, pelo visto você já possui um ticket aberto no servidor __***${reaction.message.guild.name}***__.`).catch(message.channel.send(`Tentei mandar mensagem para você no privado mas você está com o privado desativado`).then(m => m.delete({timeout: 1000}).catch(O_o=>{})));
            }
        }
    });
    }
    if (reaction.emoji.name === '🔓' && reaction.message.channel.name.includes(`•${user.discriminator}┋${user.id}`)) {
        reaction.message.channel.send(new MessageEmbed()
        .setTitle(`O mesmo decidiu fechar o ticket, e será apagado daqui 10 segundos.`)
        .setDescription(`Caso dê algum outro problema ou tenha alguma dúvida, é só abrir novamente`)
        .setColor("#2f3136"))
        setTimeout(() => {
            reaction.message.channel.delete();
        }, 1000*10);
    }
}