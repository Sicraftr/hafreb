const { MessageEmbed } = require('discord.js')
const fs = require("fs");
const { prefix } = require("../config.json");

module.exports.run = (bot,message,args) => {      
// n

  const embed = new MessageEmbed()
  

  .setTitle('Script Entradas')
  .setDescription(`
  
  ❱❱ • [**Clique Aqui**](https://srcb.in/6ACYUNupAv)`)
  .setColor("#2f3136")
  .setTimestamp()
  .setFooter('Hafreb • © Todos os direitos reservados.')
  .setImage(``)
  message.channel.send(embed)                                               
//a
}
module.exports.config = {
  name: "entradas",
  aliases: ['']
}//a