const Discord = require('discord.js');

module.exports.run = async (client, message, args) => {
    if(!message.member.hasPermission('ADMINISTRATOR')) return msg.reply('Não tens permissões para usar este comando!');

    const embed = new Discord.MessageEmbed()
    .setTitle(`**__${message.guild.name}__**`)
    .setDescription('**Para te verificares basta escreveres:** \n```/verificar```')
    .setColor("#2f3136")
	.setImage(``)
    .setFooter(`Sistema de Verificação | ${message.guild.name}`)
    message.channel.send(embed)
}
module.exports.config = {
    name: "verificarset",
    aliases: ['']
};
// ESTE COMANDO SERVER PARA O BOT MANDAR UMA MENSAGEM EMBED A DIZER COMO SE VERIFICA //
// //verificarset // comando